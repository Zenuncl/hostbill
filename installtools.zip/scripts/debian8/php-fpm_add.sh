#!/bin/bash

USER=$1
PORT=$2

if [ -z $USER ]; then
        echo "Username is required";
        exit 1;
fi

if [ -z $PORT ]; then
       PORT=9000
fi

/bin/cp -f /usr/local/hostbill/etc/php-fpm/template.conf "/etc/php/7.0/fpm/pool.d/${USER}.conf"


sed -i "s/--id--/${USER}/g" "/etc/php/7.0/fpm/pool.d/${USER}.conf"
sed -i "s/--port--/${PORT}/g" "/etc/php/7.0/fpm/pool.d/${USER}.conf"



